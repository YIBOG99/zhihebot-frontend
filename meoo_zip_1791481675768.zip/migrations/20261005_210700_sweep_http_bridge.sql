-- ============================================
-- 云端到账核验的调度通道修正（替代失败的 EDGE_FUNCTION 型任务）
-- 背景：平台 EDGE_FUNCTION 型任务以 pg_net 发起「相对路径」请求，既没补全 URL、
--       也不带 Authorization 头，函数侧无法通过身份校验 → 每轮都返回 FORBIDDEN。
-- 方案：改用 SQL 型定时任务调用本函数。函数不碰任何业务表，只做一件事——
--       向本站 Edge Function alipay-sweep 发一次带正确地址与鉴权头的 POST。
--       真实的支付宝网关查单、发卡、退款仍由 Edge Function + 既有 RPC 完成；
--       每轮结果由函数自身写入订单时间线，故不再另建执行记录表制造噪声。
-- 安全：仅授予本函数 EXECUTE，不开放任何业务表权限；口令留在 site_settings.sweep。
-- ============================================

CREATE OR REPLACE FUNCTION public.alipay_sweep_trigger()
RETURNS TEXT
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $func$
DECLARE
  cfg     JSONB;
  base    TEXT;
  token   TEXT;
  url     TEXT;
  req_id  BIGINT;
  resp    RECORD;
BEGIN
  SELECT value INTO cfg FROM public.site_settings WHERE key = 'sweep';
  base  := btrim(coalesce(cfg->>'functions_base_url', ''));
  token := btrim(coalesce(cfg->>'service_token', ''));

  -- 配置不全时直接跳过本轮，不留必然失败的噪声记录
  IF base = '' OR token = '' THEN
    RETURN '缺少 sweep.functions_base_url 或 sweep.service_token 配置';
  END IF;

  url := rtrim(base, '/') || '/functions/v1/alipay-sweep';

  SELECT net.http_post(
    url     := url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || token),
    body    := '{"source":"cron"}'::JSONB,
    timeout_milliseconds := 55000
  ) INTO req_id;

  -- 等一小会儿让异步响应落库，再取状态码用于回传摘要（失败不影响核验本身）
  PERFORM pg_sleep(2);

  SELECT * INTO resp FROM net._http_response WHERE id = req_id LIMIT 1;
  IF NOT FOUND THEN RETURN NULL; END IF;
  IF resp.status_code BETWEEN 200 AND 299 THEN RETURN NULL; END IF;
  RETURN '核验返回 ' || coalesce(resp.status_code::TEXT, '无响应') || '：' || left(coalesce(resp.error_msg, resp.content, ''), 160);
EXCEPTION WHEN OTHERS THEN
  RETURN '核验触发失败：' || SQLERRM;
END;
$func$;

REVOKE ALL ON FUNCTION public.alipay_sweep_trigger() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.alipay_sweep_trigger() TO anon, authenticated;
