-- ============================================
-- 云端到账核验：把「只有顾客页面开着才轮询」升级为「服务端每分钟自动查单」
-- 新增两个 SECURITY DEFINER 函数供 Edge Function alipay-sweep 调用：
--   alipay_sweep_candidates()  → 捞出需要向支付宝复核的在途订单（含充值单）
--   wallet_freeze_for_balance(_order_id) → 余额支付前置冻结（可选路径，当前 order_pay_with_balance 已原子扣款，本函数用于跨端预占）
-- 说明：真实网关查询在 Edge Function 内完成（数据库无法访问外网），这里只负责取候选与落库。
-- ============================================

-- 1) 待核验订单清单：已出码在途 + 已过时限未发卡 + 余额扣款待补卡
CREATE OR REPLACE FUNCTION public.alipay_sweep_candidates(_limit INT DEFAULT 50)
RETURNS JSONB
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public
AS $func$
DECLARE
  rows JSONB;
BEGIN
  SELECT coalesce(jsonb_agg(jsonb_build_object(
      'id', t.id, 'amount', t.amount, 'status', t.status,
      'payment_method', t.payment_method, 'is_recharge', t.is_recharge,
      'user_id', t.user_id, 'expires_at', t.expires_at, 'card_secret', t.card_secret
    ) ORDER BY t.created_at ASC), '[]'::JSONB)
    INTO rows
  FROM (
    SELECT id, amount, status, payment_method, is_recharge, user_id, expires_at, card_secret, created_at
      FROM public.orders
     WHERE card_secret IS NULL
       AND (
         -- 支付宝在线通道已出码、等待到账
         (status = 'pay_processing' AND payment_method IN ('alipay_qr', 'alipay_page'))
         -- 已过支付时限但仍标在途：关单前必须再确认一次真实交易状态
         OR (status = 'pay_processing' AND expires_at IS NOT NULL AND expires_at < NOW())
         -- 余额已扣但商品缺货待补发的在途单
         OR (status = 'paid_pending_delivery' AND payment_method = 'balance')
       )
     ORDER BY created_at ASC
     LIMIT greatest(1, least(coalesce(_limit, 50), 100))
  ) t;

  RETURN rows;
END;
$func$;

REVOKE ALL ON FUNCTION public.alipay_sweep_candidates(INT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.alipay_sweep_candidates(INT) TO authenticated;


-- 2) 单笔到账登记（Edge Function 查到 TRADE_SUCCESS 后调用；充值单走钱包入账，普通单走发卡）
CREATE OR REPLACE FUNCTION public.alipay_mark_settled(_order_id TEXT, _trade_no TEXT)
RETURNS TEXT
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $func$
DECLARE
  o RECORD;
  r TEXT;
BEGIN
  SELECT * INTO o FROM public.orders WHERE id = btrim(_order_id);
  IF NOT FOUND THEN RETURN '订单不存在'; END IF;
  IF o.status = 'completed' THEN RETURN NULL; END IF; -- 幂等

  IF coalesce(o.is_recharge, false) THEN
    RETURN public.wallet_credit_recharge(btrim(_order_id), o.amount, _trade_no);
  END IF;

  SELECT message INTO r FROM public.order_mark_paid(btrim(_order_id), _trade_no);
  RETURN NULL;
EXCEPTION WHEN OTHERS THEN
  RETURN '到账登记失败：' || SQLERRM;
END;
$func$;

REVOKE ALL ON FUNCTION public.alipay_mark_settled(TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.alipay_mark_settled(TEXT, TEXT) TO authenticated;
