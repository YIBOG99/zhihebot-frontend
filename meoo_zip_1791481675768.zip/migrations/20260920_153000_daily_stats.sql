-- ============================================
-- 数据看板：日活统计 + 收款聚合
-- 1) daily_stats 按日汇总表；daily_visitors / daily_login_users 去重明细表
-- 2) stat_track_visit：anon 可调，记录当日独立访客/登录用户（UTC+8 日历日）
-- 3) trg_order_revenue：订单 status 变 completed 时累加当日收款/订单数
-- 4) admin_dashboard：仅管理员可调，返回近 N 天序列 + 今日/累计标量
-- ============================================

CREATE TABLE IF NOT EXISTS public.daily_stats (
  day DATE PRIMARY KEY,
  visits INT NOT NULL DEFAULT 0,
  login_users INT NOT NULL DEFAULT 0,
  order_count INT NOT NULL DEFAULT 0,
  revenue NUMERIC(12,2) NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.daily_visitors (
  day DATE NOT NULL,
  visitor_id TEXT NOT NULL,
  PRIMARY KEY (day, visitor_id)
);

CREATE TABLE IF NOT EXISTS public.daily_login_users (
  day DATE NOT NULL,
  user_id UUID NOT NULL,
  PRIMARY KEY (day, user_id)
);

ALTER TABLE public.daily_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_visitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_login_users ENABLE ROW LEVEL SECURITY;

-- 全部读写经由 SECURITY DEFINER 函数完成，表本身不放开任何直接访问
CREATE POLICY admins_select_daily_stats ON public.daily_stats
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY admins_select_daily_visitors ON public.daily_visitors
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY admins_select_daily_login_users ON public.daily_login_users
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE INDEX IF NOT EXISTS idx_daily_stats_day ON public.daily_stats (day DESC);

-- ── 埋点上报：当日独立访客 + 登录用户去重计数 ──
CREATE OR REPLACE FUNCTION public.stat_track_visit(_visitor_id TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _today DATE := (NOW() AT TIME ZONE 'Asia/Shanghai')::date;
  _uid UUID := auth.uid();
  _is_new_visitor BOOLEAN := FALSE;
  _is_new_login BOOLEAN := FALSE;
BEGIN
  -- visitor_id 必须是 8-64 位字母数字/连字符，防脏数据
  IF _visitor_id IS NULL OR char_length(_visitor_id) < 8 OR char_length(_visitor_id) > 64
     OR _visitor_id !~ '^[A-Za-z0-9-]+$' THEN
    RETURN;
  END IF;

  INSERT INTO daily_stats (day) VALUES (_today) ON CONFLICT (day) DO NOTHING;

  BEGIN
    INSERT INTO daily_visitors (day, visitor_id) VALUES (_today, _visitor_id);
    _is_new_visitor := TRUE;
  EXCEPTION WHEN unique_violation THEN
    _is_new_visitor := FALSE;
  END;

  IF _uid IS NOT NULL THEN
    BEGIN
      INSERT INTO daily_login_users (day, user_id) VALUES (_today, _uid);
      _is_new_login := TRUE;
    EXCEPTION WHEN unique_violation THEN
      _is_new_login := FALSE;
    END;
  END IF;

  UPDATE daily_stats SET
    visits = visits + CASE WHEN _is_new_visitor THEN 1 ELSE 0 END,
    login_users = login_users + CASE WHEN _is_new_login THEN 1 ELSE 0 END,
    updated_at = NOW()
  WHERE day = _today;
END;
$$;

REVOKE ALL ON FUNCTION public.stat_track_visit(TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.stat_track_visit(TEXT) TO anon, authenticated;

-- ── 收款触发器：status 首次变为 completed 时把 amount 记入当日统计 ──
CREATE OR REPLACE FUNCTION public.trg_fn_order_revenue()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _day DATE := (NEW.updated_at AT TIME ZONE 'Asia/Shanghai')::date;
BEGIN
  IF NEW.status = 'completed' AND COALESCE(OLD.status, '') <> 'completed' THEN
    INSERT INTO daily_stats (day, order_count, revenue)
    VALUES (_day, 1, COALESCE(NEW.amount, 0))
    ON CONFLICT (day) DO UPDATE SET
      order_count = daily_stats.order_count + 1,
      revenue = daily_stats.revenue + COALESCE(NEW.amount, 0),
      updated_at = NOW();
  END IF;
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- 统计失败绝不阻断订单状态机
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_order_revenue ON public.orders;
CREATE TRIGGER trg_order_revenue
  AFTER UPDATE OF status ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.trg_fn_order_revenue();

-- ── 管理端看板聚合：近 N 天序列 + 今日/累计标量（JSONB 单值返回） ──
CREATE OR REPLACE FUNCTION public.admin_dashboard(_days INT DEFAULT 30)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _result JSONB;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RETURN '{"series": [], "today": {}, "totals": {}}'::jsonb;
  END IF;

  WITH days AS (
    SELECT (((NOW() AT TIME ZONE 'Asia/Shanghai')::date) - gs)::date AS day
    FROM generate_series(GREATEST(_days, 1) - 1, 0, -1) AS gs
  ), series AS (
    SELECT jsonb_agg(jsonb_build_object(
      'day', d.day::text,
      'visits', COALESCE(s.visits, 0),
      'order_count', COALESCE(s.order_count, 0),
      'revenue', COALESCE(s.revenue, 0)
    ) ORDER BY d.day) AS arr
    FROM days d
    LEFT JOIN daily_stats s ON s.day = d.day
  )
  SELECT jsonb_build_object(
    'series', COALESCE((SELECT arr FROM series), '[]'::jsonb),
    'today', (SELECT jsonb_build_object(
        'visits', COALESCE(visits, 0),
        'login_users', COALESCE(login_users, 0),
        'order_count', COALESCE(order_count, 0),
        'revenue', COALESCE(revenue, 0)
      ) FROM daily_stats WHERE day = ((NOW() AT TIME ZONE 'Asia/Shanghai')::date)),
    'week_visits', COALESCE((SELECT SUM(visits) FROM daily_stats
      WHERE day > ((NOW() AT TIME ZONE 'Asia/Shanghai')::date) - 7), 0),
    'total_revenue', COALESCE((SELECT SUM(amount) FROM orders WHERE status = 'completed'), 0),
    'total_orders', COALESCE((SELECT COUNT(*) FROM orders), 0),
    'pending_audit', COALESCE((SELECT COUNT(*) FROM orders
      WHERE status IN ('pending_payment','pay_processing','paid_pending_delivery')), 0)
  ) INTO _result;

  RETURN COALESCE(_result, '{}'::jsonb);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_dashboard(INT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_dashboard(INT) TO authenticated;
