-- ============================================
-- 云端到账核验的调度入口（供 Edge Function alipay-sweep 每分钟调用）
--   alipay_sweep_run() → 返回本轮要处理的订单清单 JSONB，并顺带处理无需查网关的两类：
--     · 已过支付时限但仍是 pay_processing 且未出码（pending_payment 转来的）→ 直接关单
--     · 余额已扣但商品缺货待补发的在途单 → 原路退回余额
--   真实网关查询在 Edge Function 内完成（数据库无法访问外网），这里只负责取候选 + 兜底清理。
-- 幂等：wallet_unfreeze_pending / order_expire_close 内部都有状态守卫与唯一流水关口。
-- ============================================

CREATE OR REPLACE FUNCTION public.alipay_sweep_run(_limit INT DEFAULT 40)
RETURNS JSONB
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $func$
DECLARE
  uid UUID;
  rows JSONB;
BEGIN
  -- 只有店主（admin）能触发核验，避免任意登录用户凭 RPC 探测他人订单状态
  uid := auth.uid();
  IF uid IS NULL OR NOT public.has_role(uid, 'admin') THEN
    RETURN jsonb_build_object('error', 'FORBIDDEN', 'orders', '[]'::JSONB);
  END IF;

  -- 1) 超时未付款单先做本地关单（未出码的单没有可向支付宝复核的必要）
  UPDATE public.orders
     SET status = 'closed',
         close_reason = 'timeout_auto',
         timeline = timeline || jsonb_build_object('at', now(), 'label', '超时自动关闭'),
         updated_at = NOW()
   WHERE card_secret IS NULL
     AND status = 'pending_payment'
     AND expires_at IS NOT NULL
     AND expires_at < NOW();

  -- 2) 余额已扣但未发卡且已超过时限 → 原路退回（函数内含状态与幂等守卫）
  PERFORM public.wallet_unfreeze_pending(o.id)
    FROM (SELECT id FROM public.orders
           WHERE status = 'paid_pending_delivery' AND payment_method = 'balance'
             AND card_secret IS NULL
             AND expires_at IS NOT NULL AND expires_at < NOW()
           LIMIT 10) o;

  -- 3) 需要向支付宝网关复核的在途单
  rows := public.alipay_sweep_candidates(_limit);

  RETURN jsonb_build_object('orders', coalesce(rows, '[]'::JSONB));
END;
$func$;

REVOKE ALL ON FUNCTION public.alipay_sweep_run(INT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.alipay_sweep_run(INT) TO authenticated;
