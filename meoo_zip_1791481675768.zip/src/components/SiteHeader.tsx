// 顶部导航：Logo + 分类 + 内容链接 + 登录态联动（未登录显示「登录」，已登录显示用户名下拉）
import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { Menu, X, User, LogOut, LayoutDashboard } from 'lucide-react';
import { useCategories, useBranding } from '@/lib/queries';
import { BrandLogo, useBrandName } from '@/components/BrandLogo';
import { useAuthSession } from '@/hooks/use-auth-session';
import { useIsAdmin } from '@/hooks/use-is-admin';
import { supabase } from '@/supabase/client';

const NAV_LINKS = [
  { to: '/guides', label: '选购指南' },
  { to: '/tutorials', label: '激活教程' },
  { to: '/faq', label: '常见问题' },
  { to: '/orders/lookup', label: '订单查询' },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { data: categories = [] } = useCategories();
  const { user } = useAuthSession();
  const adminState = useIsAdmin();
  const brandName = useBrandName();
  const { tagline } = useBranding();
  console.log('[SiteHeader] isAdmin =', adminState, '| 后台入口可见 =', adminState === 'granted');

  function logout() {
    supabase.auth.signOut();
    setOpen(false);
  }

  return (
    <header className="sticky top-0 z-50 bg-background/85 backdrop-blur-lg border-b border-border header-glow">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <BrandLogo size={32} />
            <span className="hidden sm:block font-semibold text-foreground tracking-tight">
              {brandName} <span className="text-muted-foreground text-xs font-normal">{tagline}</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            <Link to="/" className="px-3 py-1.5 text-sm text-muted-foreground hover:text-primary transition-colors rounded-md hover:bg-surface">
              首页
            </Link>
            {categories.slice(0, 4).map((c) => (
              <Link key={c.slug} to="/category/$slug" params={{ slug: c.slug }}
                className="px-3 py-1.5 text-sm text-muted-foreground hover:text-primary transition-colors rounded-md hover:bg-surface">
                {c.name}
              </Link>
            ))}
            {NAV_LINKS.map((l) => (
              <Link key={l.to} to={l.to as never}
                className="px-3 py-1.5 text-sm text-muted-foreground hover:text-primary transition-colors rounded-md hover:bg-surface">
                {l.label}
              </Link>
            ))}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            {user ? (
              <div className="hidden sm:flex items-center gap-2">
                {adminState === 'granted' && (
                  <Link to="/admin" title="管理后台"
                    className="flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5 text-sm font-medium text-primary hover:bg-primary/20 hover:shadow-[0_0_14px_oklch(0.75_0.17_162/0.35)] transition-all">
                    <LayoutDashboard size={14} /> 后台
                  </Link>
                )}
                <Link to="/account"
                  className="flex items-center gap-2 rounded-full border border-border bg-surface py-1.5 pl-1.5 pr-3.5 text-sm text-foreground hover:border-primary/40 transition-colors">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-primary to-neon-cyan text-xs font-bold text-primary-foreground">
                    {user.username.slice(0, 1).toUpperCase()}
                  </span>
                  <span className="max-w-[100px] truncate">{user.username}</span>
                </Link>
                <button onClick={logout} title="退出登录"
                  className="p-2 text-muted-foreground hover:text-danger rounded-md hover:bg-surface transition-colors">
                  <LogOut size={15} />
                </button>
              </div>
            ) : (
              <Link to="/login" className="btn-sheen hidden sm:flex items-center gap-1.5 rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground shadow-md shadow-primary/25 hover:bg-primary-hover transition-colors">
                <User size={14} /> 登录 / 注册
              </Link>
            )}
            {/* Mobile toggle */}
            <button onClick={() => setOpen(!open)}
              className="lg:hidden p-2 text-muted-foreground hover:text-foreground rounded-md hover:bg-surface transition-colors">
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden border-t border-border bg-surface px-4 py-3 space-y-1">
          <Link to="/" onClick={() => setOpen(false)} className="block py-2 text-sm text-muted-foreground hover:text-foreground">首页</Link>
          {categories.map((c) => (
            <Link key={c.slug} to="/category/$slug" params={{ slug: c.slug }} onClick={() => setOpen(false)}
              className="block py-2 text-sm text-muted-foreground hover:text-foreground">{c.name}</Link>
          ))}
          {NAV_LINKS.map((l) => (
            <Link key={l.to} to={l.to as never} onClick={() => setOpen(false)}
              className="block py-2 text-sm text-muted-foreground hover:text-foreground">{l.label}</Link>
          ))}
          <div className="pt-2 border-t border-border flex flex-wrap gap-4">
            {user ? (
              <>
                {adminState === 'granted' && (
                  <Link to="/admin" onClick={() => setOpen(false)} className="py-2 text-sm text-primary font-medium">后台管理</Link>
                )}
                <Link to="/account" onClick={() => setOpen(false)} className="py-2 text-sm text-foreground font-medium">{user.username} · 个人中心</Link>
                <button onClick={logout} className="py-2 text-sm text-muted-foreground hover:text-danger">退出登录</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setOpen(false)} className="py-2 text-sm text-foreground font-medium">登录 / 注册</Link>
                <Link to="/orders/lookup" onClick={() => setOpen(false)} className="py-2 text-sm text-muted-foreground hover:text-foreground">游客查单</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
