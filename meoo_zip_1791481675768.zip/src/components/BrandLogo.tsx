// 全站统一 LOGO：有图用图，无图回退能量核心图标；破图自动降级不留残骸
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { useBranding } from '@/lib/queries';
import { APP_ICON } from '@/lib/assets';

interface Props {
  /** 边长 px，默认 32 */
  size?: number;
  rounded?: 'lg' | 'full';
  className?: string;
}

const FALLBACK_NAME = '智核';

export function BrandLogo({ size = 32, rounded = 'lg', className }: Props) {
  const { logo_url, name } = useBranding();
  const [broken, setBroken] = useState(false);
  const label = (name || FALLBACK_NAME).trim();
  const radius = rounded === 'full' ? 'rounded-full' : 'rounded-lg';
  const showImg = Boolean(logo_url?.trim()) && !broken;

  if (showImg) {
    return (
      <img src={logo_url} alt={label} width={size} height={size}
        onError={() => setBroken(true)}
        style={{ width: size, height: size }}
        className={cn('shrink-0 object-cover border border-white/10 bg-background', radius, className)} />
    );
  }

  return (
    <span
      style={{ width: size, height: size }}
      className={cn('flex shrink-0 items-center justify-center overflow-hidden bg-gradient-to-br from-primary/20 to-neon-violet/20 ring-1 ring-primary/40 shadow-md shadow-primary/25', radius, className)}>
      <img src={APP_ICON} alt={label} style={{ width: size * 0.86, height: size * 0.86 }} className="object-contain" />
    </span>
  );
}

/** 店名（顶栏/页脚/后台共用），未配置时回退默认值 */
export function useBrandName(fallback = FALLBACK_NAME): string {
  const { name } = useBranding();
  return name?.trim() || fallback;
}
