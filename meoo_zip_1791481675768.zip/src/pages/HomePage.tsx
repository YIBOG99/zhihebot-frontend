import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowRight, Zap } from 'lucide-react';
import { useProducts, useContents } from '@/lib/queries';
import { ProductCard } from '@/components/ProductCard';
import { HERO_BG, BANNER_PROMO, ICON_SHIELD, ICON_BOLT, ICON_SEARCH, ICON_CHAT } from '@/lib/assets';

const FEATURES = [
  { icon: ICON_SHIELD, title: '正规渠道', desc: '只交付兑换凭证，绝不索取账号密码' },
  { icon: ICON_BOLT,   title: '自动发卡', desc: '核账完成后系统即时分配卡密' },
  { icon: ICON_SEARCH, title: '全程留痕', desc: '订单每一步都有时间线可回溯' },
  { icon: ICON_CHAT,   title: '售后兜底', desc: '激活失败可换发，问题有人跟进' },
];

function SkeletonGrid({ count = 3 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {[...Array(count)].map((_, i) => (
        <div key={i} className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="aspect-[16/9] animate-pulse bg-surface-2" />
          <div className="space-y-2 p-4">
            <div className="h-4 w-2/3 animate-pulse rounded bg-surface-2" />
            <div className="h-3 w-full animate-pulse rounded bg-surface-2" />
            <div className="h-6 w-1/2 animate-pulse rounded bg-surface-2" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function HomePage() {
  const { data: products = [], isLoading: loadingProducts } = useProducts();
  const { data: guides = [], isLoading: loadingGuides } = useContents('guide');
  const hot = products.filter((p) => p.is_hot);
  const rest = products.filter((p) => !p.is_hot).slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <img src={HERO_BG} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="hero-overlay absolute inset-0" />
        {/* 漂移光球装饰 */}
        <span className="orb pointer-events-none absolute -left-16 top-1/3 h-56 w-56 rounded-full bg-primary/10 blur-3xl" aria-hidden />
        <span className="orb-slow pointer-events-none absolute right-10 -top-10 h-64 w-64 rounded-full bg-neon-violet/10 blur-3xl" aria-hidden />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-32">
          <div className="max-w-xl reveal-up">
            <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary backdrop-blur-sm">
              <Zap size={12} /> 主营 ChatGPT · Claude · Grok 等 AI 工具充值及账号服务
            </p>
            <h1 className="text-4xl sm:text-5xl lg:text-[3.4rem] font-bold leading-[1.15] tracking-tight text-foreground [text-shadow:0_2px_24px_oklch(0.12_0.014_255/0.9)]">
              主流 AI 工具<span className="text-glow-gradient">会员权益</span><br />
              自助充值，<span className="text-glow-gradient">三步到手</span>
            </h1>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground max-w-md [text-shadow:0_1px_12px_oklch(0.12_0.014_255/0.9)]">
              覆盖 ChatGPT、Claude、Grok 等海外 AI 订阅充值与账号服务。无需国际信用卡，不用共享账号；选商品 → 支付宝扫码付款 → 凭订单号自取卡密，全程在自己账号内激活。
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/category/chatgpt"
                className="btn-sheen inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:bg-primary-hover hover:shadow-primary/40 active:scale-[0.98]">
                浏览商品 <ArrowRight size={15} />
              </Link>
              <Link to="/tutorials"
                className="inline-flex items-center gap-2 rounded-lg border border-border bg-surface/60 backdrop-blur-sm px-5 py-2.5 text-sm text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground">
                查看下单教程
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features strip */}
      <section className="border-b border-border bg-surface/60 backdrop-blur-sm">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px sm:grid-cols-4">
          {FEATURES.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="group flex flex-col items-start gap-2 p-5 sm:p-6 transition-colors hover:bg-surface-2/60">
              <span className="flex h-9 w-9 items-center justify-center transition-all group-hover:scale-110 group-hover:drop-shadow-[0_0_10px_oklch(0.75_0.17_162/0.6)]">
                <img src={Icon} alt="" width={26} height={26} className="object-contain" loading="lazy" />
              </span>
              <span className="text-sm font-semibold text-foreground">{title}</span>
              <span className="text-xs leading-relaxed text-muted-foreground">{desc}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 促销横幅 */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-14">
        <div className="glow-frame relative overflow-hidden rounded-2xl">
          <img src={BANNER_PROMO} alt="" className="absolute inset-0 h-full w-full object-cover" loading="lazy" />
          <div className="banner-overlay absolute inset-0" />
          <div className="relative flex flex-col items-start gap-2 px-6 py-8 sm:px-10 sm:py-10">
            <p className="text-xs font-semibold uppercase tracking-widest text-neon-cyan">Referral Program</p>
            <h3 className="text-xl sm:text-2xl font-bold text-foreground">邀请好友，双方各得满减券 · 好友消费还有返佣</h3>
            <Link to="/account" className="btn-sheen mt-2 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:bg-primary-hover active:scale-[0.98]">
              去个人中心生成邀请链接 <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>

      {/* Hot products */}
      {(loadingProducts || hot.length > 0) && (
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
            <div className="mb-6 flex items-end justify-between">
            <div>
              <h2 className="section-title text-xl text-foreground">本周爆款</h2>
              <p className="mt-1 pl-[14px] text-sm text-muted-foreground">下单人数最多的几个档位</p>
            </div>
              <a href="#all-products" onClick={(e) => { e.preventDefault(); document.getElementById('all-products')?.scrollIntoView({ behavior: 'smooth' }); }} className="story-link text-sm text-primary">查看全部 →</a>
          </div>
          {loadingProducts ? <SkeletonGrid count={3} /> : (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {hot.map((p, i) => (
                <div key={p.id} className="reveal-up" data-reveal-delay={String(i * 80)}>
                  <ProductCard product={p} />
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* All products */}
      {(loadingProducts || rest.length > 0) && (
        <section id="all-products" className="mx-auto max-w-7xl scroll-mt-20 px-4 sm:px-6 lg:px-8 pb-14">
          <h2 className="section-title mb-6 text-xl text-foreground">全部商品</h2>
          {loadingProducts ? <SkeletonGrid count={6} /> : (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {rest.map((p, i) => (
                <div key={p.id} className="reveal-up" data-reveal-delay={String(i * 60)}>
                  <ProductCard product={p} />
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Guides preview */}
      {(loadingGuides || guides.length > 0) && (
        <section className="border-t border-border bg-surface">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
            <div className="mb-6 flex items-end justify-between">
              <div>
                <h2 className="section-title text-xl text-foreground">选购指南</h2>
                <p className="mt-1 pl-[14px] text-sm text-muted-foreground">先想清楚要什么，再决定买哪个</p>
              </div>
              <Link to="/guides" className="story-link text-sm text-primary">更多文章 →</Link>
            </div>
            {loadingGuides ? <SkeletonGrid count={3} /> : (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                {guides.slice(0, 3).map((g) => (
                  <Link key={g.slug} to="/content/$slug" params={{ slug: g.slug }}
                    className="group rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/30">
                    <p className="mb-2 text-[10px] uppercase tracking-widest text-muted-foreground">Guide</p>
                    <h3 className="text-sm font-semibold leading-snug text-foreground group-hover:text-primary transition-colors">{g.title}</h3>
                    {g.summary && <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{g.summary}</p>}
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
}
